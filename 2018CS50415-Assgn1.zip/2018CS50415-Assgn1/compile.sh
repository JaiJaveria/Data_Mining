gcc -o apriori -O3 ./Apriori/main.cpp -lstdc++ -std=c++11 
make
