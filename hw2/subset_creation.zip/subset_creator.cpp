#include<iostream>
#include<string>
#include<bits/stdc++.h>
#include<fstream>

#define file_size 993934

using namespace std;


int main(int argc, char* argv[]){
	set<int> s;
      int num_points=stoi(argv[1]);
      string file = string(argv[2]);

      while(s.size()!= num_points){
            s.insert(rand()%file_size);
      }

      ifstream input_file;

      input_file.open(file);
      string line;
      int index=-1;
      ofstream fout;
      fout.open("output");
      while(input_file){
            getline(input_file, line);
            index++;
            if(s.find(index) != s.end()){
                  //cout<<index<<endl;
                  fout<<line<<endl;
            }
      }
      return 0;
}
